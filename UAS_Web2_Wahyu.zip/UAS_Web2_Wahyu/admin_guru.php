<?php 
include("inc_header.php");

// Cek akses
if (!in_array("guru", $_SESSION['admin_akses'])) {
    echo "Kamu tidak memiliki akses";
    include("inc_footer.php");
    exit();
}
?>

<!-- print.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Halaman Dosen</title>
    <style>
        body {
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1em;
        }

        main {
            padding: 20px;
            text-align: center;
        }

        @media print {
            body {
                margin: 0.5in;
            }

            header, footer {
                display: none;
            }

            main {
                margin-bottom: 50px;
            }
        }

        .print {
            background: blue;
            padding: 10px 20px;
            margin: auto;
            display: block;
            color: white;
            font-size: 20px;
            cursor: pointer;
            border-radius: 5px;
            border: 1px solid black;
            transition: .2s;
            transform: scale (1.03);
        }

        .print:hover {
            background: red;
        }

        a {
            text-decoration: none;
        }
    </style>
</head>

<body>
    <header>
        <h1>HALAMAN DOSEN</h1>
    </header>
    <br><br><br><br>

    <main>
        <p>Selamat datang di halaman dosen. Konten halaman dosen akan ditampilkan di sini.</p>
    </main>

    <a href="print.php" target="_blank">
        <button class="print">Print / .pdf</button> </a>
</body>

</html>


<?php include("inc_footer.php"); ?>
