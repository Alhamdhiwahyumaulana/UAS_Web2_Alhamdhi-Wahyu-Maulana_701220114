<?php
session_start();
include("inc_koneksi.php");
if (!isset($_SESSION['admin_username'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        #app {
            background-color: #3498db;
            padding: 10px;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        li {
            margin-right: 15px;
            padding: 0 10px;
            justify-content: left;
        }

        a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #ecf0f1;
        }
    </style>
</head>

<body>
    <div id="app">
        <nav>
            <ul>
                <li><a href="admin_depan.php">Mata Kuliah</a></li>
                <?php if (in_array("guru", $_SESSION['admin_akses'])) { ?>
                    <li><a href="admin_guru.php">Halaman Dosen</a></li>
                <?php } ?>
                <?php if (in_array("siswa", $_SESSION['admin_akses'])) { ?>
                    <li><a href="admin_siswa.php">Halaman Mahasiswa</a></li>
                <?php } ?>
                <?php if (in_array("spp", $_SESSION['admin_akses'])) { ?>
                    <li><a href="admin_admin.php">Halaman Admin</a></li>
                <?php } ?>
                <li><a href="logout.php">Logout > </a></li>
            </ul>
        </nav>
    </div>
</body>

</html>
