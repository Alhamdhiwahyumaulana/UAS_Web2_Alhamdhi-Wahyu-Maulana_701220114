<?php
session_start();
if (isset($_SESSION['admin_username'])) {
    header("location:admin_depan.php");
}
include("inc_koneksi.php");
$username = "";
$password = "";
$err = "";
if (isset($_POST['login'])) {
    $username  = $_POST['username'];
    $password   = $_POST['password'];
    if ($username  == '' or $password == '') {
        $err .= "<ul>Silahkan MasukKan Username dan Password!</ul>";
    }
    if (empty($err)) {
        $sql1 = "select * from admin where username = '$username' ";
        $q1 = mysqli_query($koneksi, $sql1);
        $r1 = mysqli_fetch_array($q1);
        if ($r1['password'] != md5($password)) {
            $err .= "<ul>Akun tidak di temukan</ul>";
        }
    }
    if (empty($err)) {
        $login_id = $r1['login_id'];
        $sql1 = "select * from admin_akses where login_id = '$login_id'";
        $q1 = mysqli_query($koneksi, $sql1);
        while ($r1 = mysqli_fetch_array($q1)) {
            $akses[] = $r1['akses_id'];
        }
        if (empty($akses)) {
            $err .= "<li>Anda Tidak Punya akses ke halaman admin ini</li>";
        }
    }
    if (empty($err)) {
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_akses'] = $akses;
        header("location:admin_depan.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background: url(digital-digital-art-artwork-illustration-drawing-hd-wallpaper-preview.jpg);
        }

        ul {
            color: red;
            margin-left: 2px;
            margin-top: -10px;
            font-size: 18px;
        }

        #app {
            width: 550px;
            height: 280px;
            background: #ffffff;
            opacity: 0.8;
            margin: auto;
            border-radius: 7px;
            margin-top: 130px;
            box-shadow: 0 0 10px rgba(1, 1, 1, 0.9);
        }

        h1 {
            text-align: center;
            padding: 30px;
            color: black;
            margin: -15px;
        }

        select {
            width: 305px;
            padding: 5px;
            border-radius: 5px;
            margin: auto;
            display: flex;
            box-sizing: border-box;
            text-align: center;
            font-size: 15px;
            font-family: 'Times New Roman', Times, serif;
        }

        .input {
            margin: auto;
            display: flex;
            width: 300px;
            height: 30px;
            border-radius: 3px;
            border: 2px solid blueviolet;
            color: black;
            font-size: 20px;
            font-family: 'Times New Roman', Times, serif;
        }

        .input1 {
            width: 305px;
            height: 38px;
            margin: auto;
            display: flex;
            text-align: center;
            color: black;
            display: block;
            font-size: 20px;
            background: blueviolet;
            border-radius: 5px;
            border: transparent;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(1, 1, 1, 0.4);
        }
        .input1:hover {
            background: salmon;
        }
    </style>
</head>

<body>
    <div id="app">
        <h1>Login</h1>
        <?php
        if ($err) {
            echo "<ul>$err</ul>";
        }
        ?>
        <form action="" method="post">
            <input type="text" value="<?php echo $username ?>" name="username" class="input" placeholder="Username" /> <br>
            <input type="password" name="password" class="input" placeholder="Password" /> <br>
            <input type="submit" name="login" class="input1" value="Log in" />
        </form>
    </div>
</body>

</html>